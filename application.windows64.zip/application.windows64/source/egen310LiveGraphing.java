import processing.core.*; 
import processing.data.*; 
import processing.event.*; 
import processing.opengl.*; 

import processing.serial.*; 

import java.util.HashMap; 
import java.util.ArrayList; 
import java.io.File; 
import java.io.BufferedReader; 
import java.io.PrintWriter; 
import java.io.InputStream; 
import java.io.OutputStream; 
import java.io.IOException; 

public class egen310LiveGraphing extends PApplet {



private int maxValue = 1024;
private int verticalTickNumber = 8;

private static final int WIDTH = 1024;
private static final int HEIGHT = 720;

private Serial port;

private PrintWriter output;

private int unitSalinityWidth = 10;
private int salinityOffset = 0;
private int[] salinityValues = new int[60*20];

private int unitPressureWidth = 10;
private int pressureOffset = 0;
private int[] pressureValues = new int[60*20];
private int currentTime = 0;

public void setup (){
  port = new Serial(this, Serial.list()[0], 9600);
  output = createWriter("data.csv");
  output.println("Pressure,Salinity");
  
}

int s = 0;

public void draw (){
  /*
  s++;
  if(s == 60) {
    s = 0;
    pressureValues[currentTime] = (int)random(1024);
    salinityValues[currentTime++] = (int)random(1024);
    if(currentTime >= salinityValues.length) s = 61;
  }
  */
  
  if ( port.available() > 0) {
    String temp = port.readString(); 
    if(temp.charAt(0) == 'S')
      salinityValues[currentTime] = Integer.parseInt(temp.split("S")[1]);
    else if(temp.charAt(0) == 'P')
      pressureValues[currentTime] = Integer.parseInt(temp.split("P")[1]);
      
    output.print(pressureValues[currentTime] + ",");
    output.println(salinityValues[currentTime]);
    currentTime ++;
    if(currentTime >= salinityValues.length) {
      output.flush();
      output.close();
    }
  }
  
  background(0);
  text("Pressure", WIDTH/4f, HEIGHT/20f);
  text("Salinity", 3*WIDTH/4f, HEIGHT/20f);
  for(int i = 0; i <= verticalTickNumber; i++) {
    text("" + (int)((float)i*maxValue/verticalTickNumber),10,HEIGHT - HEIGHT*(float)i/(verticalTickNumber+1)-10);
    text("" + (int)((float)i*maxValue/verticalTickNumber),10+WIDTH/2,HEIGHT - HEIGHT*(float)i/(verticalTickNumber+1)-10);
  }
  
  if(unitPressureWidth >= 15)
    for(int i = 0; i <= 400/unitPressureWidth; i++)
      text((i+1)+pressureOffset, 80+i*unitPressureWidth+1, HEIGHT);
  else
    for(int i = 0; i <= 400/unitPressureWidth; i+=(int)(400f/unitPressureWidth/3))
      text((i+1)+pressureOffset, 80+i*unitPressureWidth+1, HEIGHT);
      
  if(unitSalinityWidth >= 15)
    for(int i = 0; i <= 400/unitSalinityWidth; i++)
        text((i+1)+salinityOffset, WIDTH/2 + 80+i*unitSalinityWidth+1, HEIGHT);
  else
    for(int i = 0; i <= 400/unitSalinityWidth; i+=(int)(400f/unitSalinityWidth/3))
      text((i+1)+salinityOffset, WIDTH/2 + 80+i*unitSalinityWidth+1, HEIGHT);
  
  fill(100);
  stroke(0);
  rect(79, 65, 401, HEIGHT-75);
  rect(WIDTH/2 + 79, 65, 401, HEIGHT-75);
  
  fill(255);
  stroke(255);
  for(int i = 0; i < 400/unitPressureWidth; i++)
    rect(80 + i*unitPressureWidth, HEIGHT-10, unitPressureWidth, -((HEIGHT-75)*(float)(pressureValues[i+pressureOffset])/1024));
    
  for(int i = 0; i < 400/unitSalinityWidth; i++)
    rect(WIDTH/2 + 80 + i*unitSalinityWidth, HEIGHT-10, unitSalinityWidth, -((HEIGHT-75)*(float)(salinityValues[i+salinityOffset])/1024));
}

private int mX;

public void mousePressed(MouseEvent me){
  mX = me.getX();
}

public void mouseDragged(MouseEvent me) {
  int dX = mX - me.getX();
  if(me.getX() < WIDTH/2){
    pressureOffset += dX;
    pressureOffset = clamp(pressureOffset, 0, 1024);
  } else if(me.getX() > WIDTH/2) {
    salinityOffset += dX;
    salinityOffset = clamp(salinityOffset, 0, 1024);
  }
  mX = me.getX();
}

public void mouseWheel(MouseEvent me){
  if(me.getX() < WIDTH/2) {
    unitPressureWidth = clamp(unitPressureWidth - me.getCount(), 1, 20);
  } else {
    unitSalinityWidth = clamp(unitSalinityWidth - me.getCount(), 1, 20);
  }
}

private int clamp(int val, int min, int max){
  return val < min ? min : val > max ? max : val;
}
  public void settings() {  size(1024, 730); }
  static public void main(String[] passedArgs) {
    String[] appletArgs = new String[] { "egen310LiveGraphing" };
    if (passedArgs != null) {
      PApplet.main(concat(appletArgs, passedArgs));
    } else {
      PApplet.main(appletArgs);
    }
  }
}
