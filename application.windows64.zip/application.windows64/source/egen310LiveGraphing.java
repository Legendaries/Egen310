import processing.core.*; 
import processing.data.*; 
import processing.event.*; 
import processing.opengl.*; 

import java.awt.*; 
import java.awt.event.*; 
import processing.serial.*; 
import javax.swing.*; 
import processing.awt.PSurfaceAWT; 
import java.awt.event.KeyEvent; 

import java.util.HashMap; 
import java.util.ArrayList; 
import java.io.File; 
import java.io.BufferedReader; 
import java.io.PrintWriter; 
import java.io.InputStream; 
import java.io.OutputStream; 
import java.io.IOException; 

public class egen310LiveGraphing extends PApplet {








private int maxValue = 1024;
private int verticalTickNumber = 8;
private static final int SAMPLES_PER_MIN = 800;

private enum SAMPLE_DISPLAY_METHOD {
  POINTS, LINES, BAR
}

private SAMPLE_DISPLAY_METHOD displayMethod = SAMPLE_DISPLAY_METHOD.LINES;

private static final int WIDTH = 1024;
private static final int HEIGHT = 720;

private Serial port;

private PrintWriter output;

private int unitSalinityWidth = 10;
private int salinityOffset = 0;
private int[] salinityValues = new int[SAMPLES_PER_MIN * 20];

private int unitPressureWidth = 10;
private int pressureOffset = 0;
private int[] pressureValues = new int[SAMPLES_PER_MIN * 20];
private int currentTime = 0;


public void setup() {
  
  try {
    port = new Serial(this, Serial.list()[0], 9600);
  } catch (Exception e) {
    //e.printStackTrace();
  }
  MenuBar menu = new MenuBar();
  Menu fileMenu = new Menu("File");
  menu.add(fileMenu);
  Menu displayMenu = new Menu("Display");
  menu.add(displayMenu);
  MenuItem bar = new MenuItem("Bar Graph");
  displayMenu.add(bar);
  bar.addActionListener(new ActionListener() {
    @Override
    public void actionPerformed(ActionEvent e) {
      displayMethod = SAMPLE_DISPLAY_METHOD.BAR;
    }
  });
  MenuItem lines = new MenuItem("Line Graph");
  displayMenu.add(lines);
  lines.addActionListener(new ActionListener() {
    @Override
    public void actionPerformed(ActionEvent e) {
      displayMethod = SAMPLE_DISPLAY_METHOD.LINES;
    }
  });
  MenuItem points = new MenuItem("Point Graph");
  displayMenu.add(points);
  points.addActionListener(new ActionListener() {
    @Override
    public void actionPerformed(ActionEvent e) {
      displayMethod = SAMPLE_DISPLAY_METHOD.POINTS;
    }
  });
  MenuItem neww = new MenuItem("New");
  fileMenu.add(neww);
  neww.addActionListener(new ActionListener (){
    @Override
    public void actionPerformed(ActionEvent arg0) {
      salinityValues = new int[SAMPLES_PER_MIN * 20];
      pressureValues = new int[SAMPLES_PER_MIN * 20];
      currentTime = 0;
    }
  });
  MenuItem save = new MenuItem("Save");
  fileMenu.add(save);
  save.addActionListener(new ActionListener() {
    @Override
    public void actionPerformed(ActionEvent ae) {
      JFileChooser chooser = new JFileChooser();
      int returnVal = chooser.showOpenDialog(null);
      if (returnVal == JFileChooser.APPROVE_OPTION) {
        output = createWriter(chooser.getSelectedFile().getAbsolutePath());
        output.println("Pressure,Salinity");

        for (int i = 0; i < salinityValues.length; i++) {
          if (pressureValues[i] != 0 && salinityValues[i] != 0) {
            output.print(pressureValues[i] + ",");
            output.println(salinityValues[i]);
          }
        }

        output.flush();
        output.close();
      }
    }
  });

  PSurfaceAWT awtSurface = (PSurfaceAWT) surface;
  PSurfaceAWT.SmoothCanvas smoothCanvas = (PSurfaceAWT.SmoothCanvas) awtSurface.getNative();
  smoothCanvas.getFrame().setMenuBar(menu);
}

int s = 0;
public void draw() {
  if(port != null) {
    if (port.available() > 0) {
      String temp = port.readString();
      if (temp.charAt(0) == 'S')
        salinityValues[currentTime] = Integer.parseInt(temp.split("S")[1]);
      else if (temp.charAt(0) == 'P')
        pressureValues[currentTime] = Integer.parseInt(temp.split("P")[1]);

      if (currentTime >= salinityValues.length) {

      } else
        currentTime++;
    }
  } else {
    s++;
    if (s == 60*60/SAMPLES_PER_MIN) {
      s = 0;
      pressureValues[currentTime] = (int) random(1024);
      salinityValues[currentTime++] = (int) random(1024);
      if (currentTime >= salinityValues.length)
        s = 60*60/SAMPLES_PER_MIN+1;
    }
  }

  background(0);
  text("Pressure", WIDTH / 4f, HEIGHT / 20f);
  text("Salinity", 3 * WIDTH / 4f, HEIGHT / 20f);
  for (int i = 0; i <= verticalTickNumber; i++) {
    text("" + (int) ((float) i * maxValue / verticalTickNumber), 10,
        HEIGHT - HEIGHT * (float) i / (verticalTickNumber + 1) - 10);
    text("" + (int) ((float) i * maxValue / verticalTickNumber), 10 + WIDTH / 2,
        HEIGHT - HEIGHT * (float) i / (verticalTickNumber + 1) - 10);
  }

//    if (unitPressureWidth >= 15)
//      for (int i = 0; i <= 400 / unitPressureWidth; i++)
//        text((i + 1) + pressureOffset, 80 + i * unitPressureWidth + 1, HEIGHT);
//    else
    for (int i = 0; i <= 400 / unitPressureWidth; i += (int) (400f / unitPressureWidth / 3))
      text((i + 1) + pressureOffset, 80 + i * unitPressureWidth + 1, HEIGHT);

//    if (unitSalinityWidth >= 15)
//      for (int i = 0; i <= 400 / unitSalinityWidth; i++)
//        text((i + 1) + salinityOffset, WIDTH / 2 + 80 + i * unitSalinityWidth + 1, HEIGHT);
//    else
    for (int i = 0; i <= 400 / unitSalinityWidth; i += (int) (400f / unitSalinityWidth / 3))
      text((i + 1) + salinityOffset, WIDTH / 2 + 80 + i * unitSalinityWidth + 1, HEIGHT);

  fill(100);
  stroke(0);
  rect(79, 65, 401, HEIGHT - 75);
  rect(WIDTH / 2 + 79, 65, 401, HEIGHT - 75);

  fill(255);
  stroke(255);

  switch(displayMethod){
    case BAR:
      stroke(0);
      colorMode(HSB, 255);
      for (int i = 0; i < 400 / unitPressureWidth; i++)
        if (i + pressureOffset < pressureValues.length)
          if(pressureValues[i + pressureOffset] != 0) {
            fill(map(i+pressureOffset, 0, pressureValues.length/SAMPLES_PER_MIN*10, 0, 255)%255, 255, 255);
            rect(80 + i * unitPressureWidth, HEIGHT - 10, unitPressureWidth, -((HEIGHT - 75) * (float) (pressureValues[i + pressureOffset]) / 1024));
          }

      for (int i = 0; i < 400 / unitSalinityWidth; i++)
        if (i + salinityOffset < salinityValues.length)
          if(salinityValues[i + salinityOffset] != 0) {
            fill(map(i+salinityOffset, 0, salinityValues.length/SAMPLES_PER_MIN*10, 0, 255)%255, 255, 255);
            rect(WIDTH / 2 + 80 + i * unitSalinityWidth, HEIGHT - 10, unitSalinityWidth, -((HEIGHT - 75) * (float) (salinityValues[i + salinityOffset]) / 1024));
          }
      colorMode(RGB, 255);
      fill(255);
      stroke(255);
      break;
    case LINES:
      strokeWeight(2);
      for (int i = 0; i < 400 / unitPressureWidth; i++)
        if (i + pressureOffset < pressureValues.length) {
          if(i-1 >= 0 && pressureValues[i + pressureOffset] != 0)
            line(80 + i * unitPressureWidth, HEIGHT - 10 -((HEIGHT - 75) * (float) (pressureValues[i + pressureOffset]) / 1024), 80 + (i-1) * unitPressureWidth, HEIGHT - 10 -((HEIGHT - 75) * (float) (pressureValues[(i-1) + pressureOffset]) / 1024));
          if(pressureValues[i + pressureOffset] != 0)
            point(80 + i * unitPressureWidth, HEIGHT - 10 -((HEIGHT - 75) * (float) (pressureValues[i + pressureOffset]) / 1024));
        }

      for (int i = 0; i < 400 / unitSalinityWidth; i++)
        if (i + salinityOffset < salinityValues.length) {
          if(i-1 >= 0 && salinityValues[i + salinityOffset] != 0)
            line(WIDTH / 2 + 80 + i * unitSalinityWidth, HEIGHT - 10 -((HEIGHT - 75) * (float) (salinityValues[i + salinityOffset]) / 1024), WIDTH / 2 + 80 + (i-1) * unitSalinityWidth, HEIGHT - 10 -((HEIGHT - 75) * (float) (salinityValues[(i-1) + salinityOffset]) / 1024));
          if(salinityValues[i + salinityOffset] != 0)
            point(WIDTH / 2 + 80 + i * unitSalinityWidth, HEIGHT - 10 -((HEIGHT - 75) * (float) (salinityValues[i + salinityOffset]) / 1024));
        }
      strokeWeight(1);
      break;
    case POINTS:
      strokeWeight(4);
      for (int i = 0; i < 400 / unitPressureWidth; i++)
        if (i + pressureOffset < pressureValues.length)
          if(pressureValues[i + pressureOffset] != 0)
            point(80 + i * unitPressureWidth, HEIGHT - 10 -((HEIGHT - 75) * (float) (pressureValues[i + pressureOffset]) / 1024));

      for (int i = 0; i < 400 / unitSalinityWidth; i++)
        if (i + salinityOffset < salinityValues.length)
          if(salinityValues[i + salinityOffset] != 0)
            point(WIDTH / 2 + 80 + i * unitSalinityWidth, HEIGHT - 10 -((HEIGHT - 75) * (float) (salinityValues[i + salinityOffset]) / 1024));
      strokeWeight(1);
      break;
  }
}

private int mX;

private boolean shiftDown = false;
private boolean ctrlDown = false;
public void keyPressed(){
  if(keyCode == KeyEvent.VK_SHIFT)
    shiftDown = true;
  if(keyCode == KeyEvent.VK_CONTROL)
    ctrlDown = true;
}

public void keyReleased(){
  if(keyCode == KeyEvent.VK_SHIFT)
    shiftDown = false;
  if(keyCode == KeyEvent.VK_CONTROL)
    ctrlDown = false;
}

public void mousePressed() {
  mX = mouseX;
}

public void mouseDragged() {
  
  int dX = 0;
  if(shiftDown)
    dX = (mX - mouseX)*10;
  else if (ctrlDown)
    dX = (mX - mouseX)*100;
  else
    dX = mX - mouseX;
  if (mouseX < WIDTH / 2) {
    pressureOffset += dX/2;
    pressureOffset = clamp(pressureOffset, 0, pressureValues.length);
  } else if (mouseX > WIDTH / 2) {
    salinityOffset += dX/2;
    salinityOffset = clamp(salinityOffset, 0, salinityValues.length);
  }
  mX = mouseX;
}

public void mouseWheel(processing.event.MouseEvent me) {
  if (mouseX < WIDTH / 2)
    unitPressureWidth = clamp(unitPressureWidth - me.getCount(), 2, 20);
  else
    unitSalinityWidth = clamp(unitSalinityWidth - me.getCount(), 2, 20);
}

private int clamp(int val, int min, int max) {
  return val < min ? min : val > max ? max : val;
}
  public void settings() {  size(1024, 760); }
  static public void main(String[] passedArgs) {
    String[] appletArgs = new String[] { "egen310LiveGraphing" };
    if (passedArgs != null) {
      PApplet.main(concat(appletArgs, passedArgs));
    } else {
      PApplet.main(appletArgs);
    }
  }
}
